import React, { useState, useEffect, useMemo } from "react";
import { signInAnonymously, onAuthStateChanged } from "firebase/auth";
import { collection, onSnapshot } from "firebase/firestore";
import { auth, db } from "./firebase";

const App = () => {
  const [menu, setMenu] = useState([]);
  const [order, setOrder] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) await signInAnonymously(auth);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "pizzeria_menu"), (snap) => {
      setMenu(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const addItem = (id) => setOrder((o) => ({ ...o, [id]: (o[id] || 0) + 1 }));
  const removeItem = (id) =>
    setOrder((o) => {
      const c = { ...o };
      if (c[id] > 1) c[id]--;
      else delete c[id];
      return c;
    });

  const items = useMemo(
    () =>
      menu
        .filter((i) => order[i.id])
        .map((i) => ({ ...i, qty: order[i.id], subtotal: i.price * order[i.id] })),
    [menu, order]
  );
  const total = items.reduce((s, i) => s + i.subtotal, 0);

  const sendWhatsApp = () => {
    const phone = "541150550793";
    const msg =
      "Pedido:\n" +
      items.map((i) => `${i.qty}x ${i.name} ($${i.subtotal})`).join("\n") +
      `\nTotal: $${total}`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`);
  };

  if (loading)
    return (
      <div className="flex h-screen items-center justify-center text-red-600">
        Cargando menú...
      </div>
    );

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <header className="bg-red-700 text-white p-4 text-center text-3xl font-bold">
        🍕 La TronerA
      </header>

      <main className="p-6 grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-4">
          {menu.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-xl shadow">
              <h3 className="text-lg font-bold text-red-600">{item.name}</h3>
              <p>{item.description}</p>
              <p className="font-semibold">${item.price}</p>
              <div className="flex mt-2 space-x-2">
                <button
                  onClick={() => removeItem(item.id)}
                  className="bg-red-400 px-3 py-1 rounded text-white"
                >
                  -
                </button>
                <span>{order[item.id] || 0}</span>
                <button
                  onClick={() => addItem(item.id)}
                  className="bg-green-500 px-3 py-1 rounded text-white"
                >
                  +
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="text-xl font-bold mb-3 border-b pb-1">🛒 Tu Pedido</h2>
          {items.length === 0 ? (
            <p className="italic text-gray-500">Vacío</p>
          ) : (
            <>
              {items.map((i) => (
                <p key={i.id}>
                  {i.qty}x {i.name} (${i.subtotal})
                </p>
              ))}
              <p className="mt-2 font-bold">Total: ${total}</p>
              <button
                onClick={sendWhatsApp}
                className="mt-3 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg"
              >
                Enviar pedido
              </button>
            </>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;